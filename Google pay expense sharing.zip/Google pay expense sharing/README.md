# Google Pay Expense Sharing

## Project Overview
This project is a Python-based expense sharing system, similar to Google Pay's group expense tracking. 
It allows multiple users to add expenses, track balances, and calculate reimbursements.

## Features
- Add users
- Record expenses
- Calculate balances for each member
- Clear or delete individual/all users

## Requirements
- Python 3.x
- Jupyter Notebook (to run .ipynb file)

## Setup Instructions
1. Install Python 3.x from [Python Official Site](https://www.python.org/).
2. Install Jupyter Notebook using pip:
   ```bash
   pip install notebook
   ```
3. Open the notebook:
   ```bash
   jupyter notebook "Google Pay Expense Sharing.ipynb"
   ```

## Usage
- Run each cell in the notebook step by step.
- Follow the prompts to add users, enter expenses, and view balances.

## Demo
Include  a short video showcasing the working project.

## Author
Keerthiraja T.M
